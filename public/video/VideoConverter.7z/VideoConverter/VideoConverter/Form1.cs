﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using AsfMojo.Media;
using DirectShowLib;

namespace VideoConverter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<Bitmap> bitmaps = new List<Bitmap>();

        private void openFileButton_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                statusLabel.Text = "Открытие...";
                filePathTextBox.Text = openFileDialog1.FileName;
                Bitmap bitmap = AsfImage.FromFile(openFileDialog1.FileName)
                        .AtOffset(1.0);
                statusLabel.Text = "Файл открыт";
            }
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            int FPS = (int)numericUpDown1.Value;
            double step = 1.0 / Convert.ToDouble(FPS);
            bitmaps.Clear();
            statusLabel.Text = "Рассчёт...";
            double videoLenght = GetVideoLength(openFileDialog1.FileName);
            for (int i = 0, countFrames = 0; ; i++)
                try
                {
                    bitmaps.Add(AsfImage.FromFile(openFileDialog1.FileName)
                            .AtOffset(i * step));
                    if (bitmaps[i] == null)
                    {
                        bitmaps.RemoveAt(i);
                    }
                    else
                        countFrames++;
                }
                catch (Exception)
                {
                    trackBar1.Maximum = countFrames - 1;
                    currentFramePictureBox.BackgroundImage = bitmaps[0];
                    break;
                }
            statusLabel.Text = "";
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if(trackBar1.Value != -1 && trackBar1.Maximum != 0)
                currentFramePictureBox.BackgroundImage = bitmaps[trackBar1.Value];
        }

        static public double GetVideoLength(string fileName)
        {
            FilterGraph graphFilter = new FilterGraph();
            DirectShowLib.IGraphBuilder graphBuilder;
            DirectShowLib.IMediaPosition mediaPos;
            double length = 0.0;

            try
            {
                graphBuilder = (DirectShowLib.IGraphBuilder)graphFilter;
                graphBuilder.RenderFile(fileName, null);
                mediaPos = (DirectShowLib.IMediaPosition)graphBuilder;
                mediaPos.get_Duration(out length);
                return length;
            }
            catch
            {
                return length;
            }
            finally
            {
                mediaPos = null;
                graphBuilder = null;
                graphFilter = null;
            }
        }

        Point startPosition = new Point();
        private Rectangle selectedFragment;
        bool segmentSelected = false, startPointChoose = false;
        private void currentFramePictureBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (segmentSelected)
            {
                startPosition.X = e.X;
                startPosition.Y = e.Y;
                startPointChoose = true;
            }
        }

        private void currentFramePictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            if(segmentSelected && startPointChoose)
            {
                int rectangleX = Math.Min(startPosition.X, e.X), rectangleY = Math.Min(startPosition.Y, e.Y);
                selectedFragment = new Rectangle(rectangleX, rectangleY, Math.Abs(startPosition.X - e.X), Math.Abs(startPosition.Y - e.Y));
                currentFramePictureBox.Invalidate();
            }
        }

        private void currentFramePictureBox_MouseUp(object sender, MouseEventArgs e)
        {
            if (segmentSelected)
            {
                startPointChoose = false;
            }
        }

        private void currentFramePictureBox_Paint(object sender, PaintEventArgs e)
        {
            if (segmentSelected)
            {
                e.Graphics.ResetClip();
                ControlPaint.DrawFocusRectangle(e.Graphics, selectedFragment);
            }
        }

        private void cutButton_Click(object sender, EventArgs e)
        {
            int realImageWidth = bitmaps[0].Size.Width,
                realImageHeight = bitmaps[0].Size.Height,
                pictureBoxWidth = currentFramePictureBox.Size.Width,
                pictureBoxHeight = currentFramePictureBox.Size.Height;

            double zoomCoefWidth = (double)realImageWidth / pictureBoxWidth,
                zoomCoefHeight = (double)realImageHeight / pictureBoxHeight,
                zoomCoef;
            if (realImageWidth > pictureBoxWidth || realImageHeight > pictureBoxHeight)
                zoomCoef = Math.Max(zoomCoefWidth, zoomCoefHeight);
            else
                zoomCoef = Math.Min(zoomCoefWidth, zoomCoefHeight);

            int zoomImageWidth = Convert.ToInt32(realImageWidth / zoomCoef),
                zoomImageHeight = Convert.ToInt32(realImageHeight / zoomCoef);
            int offsetX = pictureBoxWidth / 2 - zoomImageWidth / 2;
            int offsetY = pictureBoxHeight / 2 - zoomImageHeight / 2;
            selectedFragment.X -= offsetX;
            selectedFragment.Y -= offsetY;

            int selectedFragmentSizeWidthOnZoomImage = selectedFragment.Width,
                selectedFragmentSizeHeightOnZoomImage = selectedFragment.Height,
                selectedFragmentPosXOnZoomImage = selectedFragment.X,
                selectedFragmentPosYOnZoomImage = selectedFragment.Y;
            double selectedFragmentSizeWidthOnRealImage = selectedFragmentSizeWidthOnZoomImage * zoomCoef,
                selectedFragmentSizeHeightOnRealImage = selectedFragmentSizeHeightOnZoomImage * zoomCoef,
                selectedFragmentPosXOnRealImage = selectedFragmentPosXOnZoomImage * zoomCoef,
                selectedFragmentPosYOnRealImage = selectedFragmentPosYOnZoomImage * zoomCoef;
            if (selectedFragmentPosXOnRealImage < 0)
            {
                selectedFragmentSizeWidthOnRealImage += selectedFragmentPosXOnRealImage;
                selectedFragmentPosXOnRealImage = 0;
            }
            else if (selectedFragmentPosXOnRealImage > realImageWidth)
                selectedFragmentPosXOnRealImage = realImageWidth;
            if (selectedFragmentPosYOnRealImage < 0)
            {
                selectedFragmentSizeHeightOnRealImage += selectedFragmentPosYOnRealImage;
                selectedFragmentPosYOnRealImage = 0;
            }
            else if (selectedFragmentPosYOnRealImage > realImageHeight)
                selectedFragmentPosYOnRealImage = realImageHeight;
            if(selectedFragmentPosXOnRealImage + selectedFragmentSizeWidthOnRealImage > realImageWidth)
            {
                selectedFragmentSizeWidthOnRealImage -=
                    selectedFragmentPosXOnRealImage + selectedFragmentSizeWidthOnRealImage - realImageWidth;
            }
            if (selectedFragmentPosYOnRealImage + selectedFragmentSizeHeightOnRealImage > realImageHeight)
            {
                selectedFragmentSizeHeightOnRealImage -=
                    selectedFragmentPosYOnRealImage + selectedFragmentSizeHeightOnRealImage - realImageHeight;
            }
            selectedFragment = new Rectangle();
            for(int i = 0; i < bitmaps.Count; i++)
                bitmaps[i] = bitmaps[i].Clone(new Rectangle((int)selectedFragmentPosXOnRealImage, (int)selectedFragmentPosYOnRealImage,
                                (int)selectedFragmentSizeWidthOnRealImage, (int)selectedFragmentSizeHeightOnRealImage), System.Drawing.Imaging.PixelFormat.Undefined);
            if (trackBar1.Value != -1 && trackBar1.Maximum != 0)
                currentFramePictureBox.BackgroundImage = bitmaps[trackBar1.Value];
        }

        private void saveFileButton_Click(object sender, EventArgs e)
        {
            if(folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                for(int i = 0; i < bitmaps.Count; i++)
                {
                    bitmaps[i].Save(folderBrowserDialog1.SelectedPath + "\\" + i + ".jpg");
                }
            }
        }

        private void segmentButton_Click(object sender, EventArgs e)
        {
            if(segmentSelected)
            {
                segmentButton.Text = "Выделить часть";
                segmentSelected = false;
            }
            else
            {
                segmentButton.Text = "Закончить выделение";
                segmentSelected = true;
            }
        }
    }
}
